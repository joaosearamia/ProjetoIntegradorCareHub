// Export pages
export '/home_page/home_page_widget.dart' show HomePageWidget;
export '/emergencia/emergencia_widget.dart' show EmergenciaWidget;
export '/fichapaciente/fichapaciente_widget.dart' show FichapacienteWidget;
export '/agend_consulta/agend_consulta_widget.dart' show AgendConsultaWidget;
export '/criarconta/criarconta_widget.dart' show CriarcontaWidget;
export '/segundo_login/segundo_login_widget.dart' show SegundoLoginWidget;
export '/redefinir_senha/redefinir_senha_widget.dart' show RedefinirSenhaWidget;
export '/perfil_editavel/perfil_editavel_widget.dart' show PerfilEditavelWidget;
export '/menuda_conta/menuda_conta_widget.dart' show MenudaContaWidget;
export '/editar_perfil/editar_perfil_widget.dart' show EditarPerfilWidget;
export '/saude/saude_widget.dart' show SaudeWidget;
