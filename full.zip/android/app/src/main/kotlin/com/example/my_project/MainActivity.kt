package com.mycompany.carehub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
